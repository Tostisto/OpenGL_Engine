﻿/*
	Name: Jakub Czepiec
	Login: CZE0043
*/

#include "Application.h"

int main(void)
{
	Application* app = new Application();

	app->Run();
}