#include "FragmentShader.h"

FragmentShader::FragmentShader(const char* shaderPath) : Shader(GL_FRAGMENT_SHADER, shaderPath) {}