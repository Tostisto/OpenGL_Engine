#include "Scene.h"

#include "sphere.h"
#include "suzi_smooth.h"

Scene::Scene(Window* window)
{
	this->window = window;

	this->drawables = std::vector<Drawable*>();

	// Model 1
	Model* model = new Model(suziSmooth, 2904, 6);
	Drawable* drawable = new Drawable(model);

	this->AddDrawable(drawable);

	// Model 1 Shaders
	VertexShader* vertexShaderTest = new VertexShader("Shaders\\shader.vert");
	FragmentShader* fragmentShaderTest = new FragmentShader("Shaders\\shader.frag");
	ShaderProgram* shaderProgram = new ShaderProgram(vertexShaderTest, fragmentShaderTest);

	this->shaderPrograms.push_back(shaderProgram);


	// Camera
	this->camera = new Camera();

	this->cameraControll = new CameraControll(this->camera, this->window);
	Callback::GetInstance()->Attach(this->cameraControll);


	// Attach camera to shaders
	this->camera->Attach(shaderProgram);
}

void Scene::AddDrawable(Drawable* drawable)
{
	this->drawables.push_back(drawable);
}

void Scene::RemoveDrawable(Drawable* drawable)
{
	for (int i = 0; i < this->drawables.size(); i++) {
		if (this->drawables[i] == drawable) {
			this->drawables.erase(this->drawables.begin() + i);
			return;
		}
	}
}

void Scene::Render()
{
	this->cameraControll->KeyboardMovement();

	// Projection matrix
	glm::mat4 projectionMatrix = this->window->GetProjectionMatrix();

	// Transformation vector
	std::vector<glm::mat4> transformations = std::vector<glm::mat4>();


	// Model 1
	float angleInRadians1 = static_cast<float>(glm::radians(20.0));
	Rotation* rotation1 = new Rotation(angleInRadians1, glm::vec3(1.0f, 1.0f, 1.0f));
	Translation* translation1 = new Translation(glm::vec3(1.0f, 1.0f, 1.0f));
	Scale* scale1 = new Scale(glm::vec3(0.5f, 0.5f, 0.5f));

	TransformCollection* transformationCollection1 = new TransformCollection();
	//transformationCollection1->addTransformation(rotation1);
	//transformationCollection1->addTransformation(translation1);
	transformationCollection1->addTransformation(scale1);

	transformations.push_back(transformationCollection1->getMatrix());


	for (int i = 0; i < this->drawables.size(); i++) {

		this->drawables[i]->LinkShaderProgram(this->shaderPrograms[i]);

		this->shaderPrograms[i]->setUniform("modelMatrix", transformations[i]);

		this->shaderPrograms[i]->setUniform("projectionMatrix", projectionMatrix);

		this->drawables[i]->Render();
	}
}