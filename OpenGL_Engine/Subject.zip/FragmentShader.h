#pragma once

#include "Shader.h"

class FragmentShader : public Shader
{
public:
	FragmentShader(const char* shaderPath);
};

