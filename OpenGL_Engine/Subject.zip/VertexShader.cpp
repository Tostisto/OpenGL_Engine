#include "VertexShader.h"

VertexShader::VertexShader(const char* shaderPath) : Shader(GL_VERTEX_SHADER, shaderPath) {}